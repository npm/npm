Package for npm-test-noproxy.
